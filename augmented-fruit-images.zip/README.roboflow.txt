
yapayzeka2 - v2 2022-05-29 10:41pm
==============================

This dataset was exported via roboflow.ai on May 29, 2022 at 7:42 PM GMT

It includes 647 images.
Fruit are annotated in COCO Segmentation format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 512x512 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -30 and +30 degrees
* Random exposure adjustment of between -41 and +41 percent
* Random Gaussian blur of between 0 and 3.25 pixels


